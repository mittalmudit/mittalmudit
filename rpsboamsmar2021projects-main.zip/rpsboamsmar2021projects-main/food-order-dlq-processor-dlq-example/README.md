# food-order-dlq-processor

Code written for the following blog posts:

http://e4developer.com/2018/02/05/handling-bad-messages-with-rabbitmq-and-spring-cloud-stream/
