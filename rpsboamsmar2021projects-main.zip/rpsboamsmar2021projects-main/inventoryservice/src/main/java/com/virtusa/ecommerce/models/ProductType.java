package com.virtusa.ecommerce.models;

public enum ProductType {
 Electronics,Furniture,Garments,HomeAppliances
}
