package com.e4developer.foodorderpublisher;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FoodOrderPublisherApplicationTests {

	@Test
	public void contextLoads() {
	}

}
