package com.e4developer.foodorderpublisher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodOrderPublisherApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodOrderPublisherApplication.class, args);
	}
}
