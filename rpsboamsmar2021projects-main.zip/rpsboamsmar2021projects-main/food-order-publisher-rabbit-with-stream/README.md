# food-order-publisher
Code written for the blog post: http://e4developer.com/2018/01/28/setting-up-rabbitmq-with-spring-cloud-stream/
