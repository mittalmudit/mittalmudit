package com.boa.kyc.upload.models;

public enum AccountType {

	SAVINGS,CURRENT,DEMAT,LOAN
}
